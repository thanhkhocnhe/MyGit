# projeto-mpu6050-nodeMCU
código fonte do artigo "Monitoramento Remoto do Acelerômetro MPU6050 com NodeMCU" para o blog da Filipeflop

**nodejs-server** contém o código do servidor escrito em Node.js

**nodemcu-client-arduino** contém o código para ser usado na IDE Arduino
